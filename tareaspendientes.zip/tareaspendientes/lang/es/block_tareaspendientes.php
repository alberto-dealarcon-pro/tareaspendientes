<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Bloque Tareas Pendientes Pro';
$string['ejemplo:addinstance'] = 'Añadir un bloque de tareas pendientes pro';
$string['ejemplo:myaddinstance'] = 'Añadir el bloque de tareas pendientes pro a Mi Moodle';
$string['nocapability'] = 'No tienes permisos para ver las tareas pendientes.';
$string['notasks'] = 'No hay tareas pendientes de calificación en este curso.';

